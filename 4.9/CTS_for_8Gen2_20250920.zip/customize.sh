ClearConfig(){
    mkdir  /sdcard/Android/MW_CpuSpeedController
    sleep 0.2s
    mv -f "/sdcard/Android/MW_CpuSpeedController/config.ini" "/sdcard/Android/MW_CpuSpeedController/config.ini.bak"
    mv -f "/sdcard/Android/MW_CpuSpeedController/Performance.conf" "/sdcard/Android/MW_CpuSpeedController/Performance.conf.bak"
}

showLog() {
    cat "$MODPATH/updateLog.txt"
}

# 音量键监听函数
getVolumeKey() {
  sleep 1
  ui_print "按[音量+]选择（1）；按[音量-]选择（2）"
  keyInfo=true
  while $keyInfo; do
    keyInfo=$(getevent -qlc 1 | grep KEY_VOLUME)
    if [ "$keyInfo" == "" ]; then
      continue
    else
      isUpKey=$(echo $keyInfo | grep KEY_VOLUMEUP)
      [ "$isUpKey" != "" ] && return 0 || return 1
      break
    fi
  done
}

install_fas() {
    if [ -n "$KSU" ] && [ "$KSU" = true ]; then
      echo ""
      echo "请选择需要安装的fas-rs"
      echo "如果你不了解两者的差异，请选择（1）！"
      echo "（1）4.9.0 CI-BUILD"
      echo "（2）4.1.0 Pro"
      if getVolumeKey; then
      ksu --install-module "$MODPATH/fas-rs-without-vtools-490.zip"
      echo "- 你选择安装fas-rs
  - 游戏将由fas-rs接管
  - fas-rs version : 4.9.0
  - from CoolApk@:shadow3"
      else
      ksu --install-module "$MODPATH/fas-rs-without-vtools-410.zip"
      echo "- 你选择安装fas-rs
  - 游戏将由fas-rs接管
  - fas-rs version : 4.1.0 Pro
  - from CoolApk@:shadow3, nnbhsi"
      fi
    else
      echo ""
      echo "请选择需要安装的fas-rs"
      echo "如果你不了解两者的差异，请选择（1）！"
      echo "（1）4.9.0 CI-BUILD"
      echo "（2）4.1.0 Pro"
      if getVolumeKey; then
      magisk --install-module "$MODPATH/fas-rs-without-vtools-490.zip"
      echo "- 你选择安装fas-rs
  - 游戏将由fas-rs接管
  - fas-rs version : 4.9.0
  - from CoolApk@:shadow3"
      else
      magisk --install-module "$MODPATH/fas-rs-without-vtools-410.zip"
      echo "- 你选择安装fas-rs
  - 游戏将由fas-rs接管
  - fas-rs version : 4.1.0 Pro
  - from CoolApk@:shadow3, nnbhsi"
      fi
      echo "fas-rs安装后，游戏必须使用极速模式！"
    fi
}

enforce_install_from_magisk_app() {
echo "欢迎使用CTS for 8Gen2调度"
echo "感谢:
CookApk@:ztc1997
CookApk@:Nep_Timeline
CoolApk@:XShee
CoolApk@:RalseiNEO
CoolApk@:hfdem
QQ@:shrairo
QQ@长虹久奕.
提供的技术支持
-------------------
配置文件作者提示：
日常请使用省电模式！"
showLog
Fas="false"
if [ -d "/data/adb/modules/fas_rs" ]; then
    Fas="true"
    echo ""
    echo "你已安装了fas-rs"
    echo "开始检测冲突"
    if [ -d "/data/adb/modules/fas_rs/vtools" ]; then
echo "检测到冲突文件，是否执行去冲突操作？
若不执行，可选择删除fas-rs
删除后，你可在下一步安装适配的fas-rs
（1）是
（2）否，并删除fas-rs"
     if getVolumeKey; then
      echo "- 你选择执行去冲突操作"
      rm -rf "/data/adb/modules/fas_rs/vtools"
      cp $MODPATH/fas_uninstall.sh /data/adb/modules/fas_rs/uninstall.sh
      echo "- 去冲突操作执行完毕"
     else
      echo "- 你选择不执行去冲突操作"
      echo "- 删除fas-rs"
      sh /data/adb/modules/fas_rs/uninstall.sh
      Fas="false"
      echo "- 删除完毕"
     fi
    else
      echo "未检测到冲突"
      echo "是否希望重新安装fas-rs？
（1）是
（2）否"
      if getVolumeKey; then
      echo "- 你选择重新安装fas-rs"
      install_fas
      else
      echo "- 你选择不重新安装fas-rs"
      fi
    fi
fi

if [ "$Fas" = "false" ]; then
    echo "
fas-rs未安装！
是否安装fas-rs？安装后，游戏将由fas-rs调度接管。
（1）是
（2）否"
    if getVolumeKey; then
      install_fas
      Fas="true"
    else
      echo "- 你选择不安装fas-rs"
      echo "- 王者荣耀请使用均衡模式，
- 和平精英、金铲铲请使用性能模式，
- 更高压力游戏（如原神、鸣潮等）请使用极速模式，
- 相机请使用极速模式。"
    fi
fi

if [ "$Fas" = "false" ]; then
cat $MODPATH/conf/basic.ini > /sdcard/Android/MW_CpuSpeedController/config.ini
else
cat $MODPATH/conf/basic_fas.ini > /sdcard/Android/MW_CpuSpeedController/config.ini
fi
echo "" >> /sdcard/Android/MW_CpuSpeedController/config.ini
echo "请选择你的[性能模式]需要适配的游戏：
（1）金铲铲之战
（2）和平精英
如果都不是，接下来请全部选择（1）。"
if getVolumeKey; then
echo "- 你选择金铲铲之战，请选择所需适配的分辨率，
画质默认为[高]，帧率默认为60Hz。
（1）高清（720p）
（2）超清（2k）"
  if getVolumeKey; then
   echo "- 你选择高清分辨率"
   if [ "$Fas" = "false" ]; then
   cat $MODPATH/conf/jks720.ini >> /sdcard/Android/MW_CpuSpeedController/config.ini
   else
   cat $MODPATH/conf/jks720_fas.ini >> /sdcard/Android/MW_CpuSpeedController/config.ini
   fi
   sleep 0.3s
   rm -rf $MODPATH/conf/jks720.ini
  else
   echo "- 你选择超清分辨率"
   if [ "$Fas" = "false" ]; then
   cat $MODPATH/conf/jks2k.ini >> /sdcard/Android/MW_CpuSpeedController/config.ini
   else
   cat $MODPATH/conf/jks2k_fas.ini >> /sdcard/Android/MW_CpuSpeedController/config.ini
   fi
   sleep 0.3s
   rm -rf $MODPATH/conf/jks2k.ini
  fi
else
  echo "- 你选择和平精英，请选择所需适配的帧率，画质默认为[流畅]。
（1）90Hz
（2）120Hz"
  if getVolumeKey; then
   echo "- 你选择90Hz"
   if [ "$Fas" = "false" ]; then
   cat $MODPATH/conf/pubg90.ini >> /sdcard/Android/MW_CpuSpeedController/config.ini
   else
   cat $MODPATH/conf/pubg90_fas.ini >> /sdcard/Android/MW_CpuSpeedController/config.ini
   fi
   sleep 0.3s
   rm -rf $MODPATH/conf/pubg90.ini
  else
   echo "- 你选择120Hz"
   if [ "$Fas" = "false" ]; then
   cat $MODPATH/conf/pubg120.ini >> /sdcard/Android/MW_CpuSpeedController/config.ini
   else
   cat $MODPATH/conf/pubg120_fas.ini >> /sdcard/Android/MW_CpuSpeedController/config.ini
   fi
   sleep 0.3s
   rm -rf $MODPATH/conf/pubg120.ini
  fi
fi
echo "" >> /sdcard/Android/MW_CpuSpeedController/config.ini
cat $MODPATH/conf/end.ini >> /sdcard/Android/MW_CpuSpeedController/config.ini
cp -f "$MODPATH/Performance.conf" "/sdcard/Android/MW_CpuSpeedController/Performance.conf"
}

Init(){
killall -9 MW_CpuSpeedController
sh $MODPATH/vtools/init_vtools.sh $(realpath $MODPATH/module.prop)
echo " powersave" > /sdcard/Android/MW_CpuSpeedController/config.txt
}

ClearConfig
enforce_install_from_magisk_app
Init