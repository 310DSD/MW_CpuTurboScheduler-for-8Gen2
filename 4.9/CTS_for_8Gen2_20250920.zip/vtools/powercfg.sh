#!/system/bin/sh



switch_mode() {
    echo "$1" > /sdcard/Android/MW_CpuSpeedController/config.txt
}

case $1 in
       "powersave" | "standby")
        switch_mode "$1" ;;
    "balance" | "performance" | "fast")
        switch_mode "$1" ;;
    *)
esac