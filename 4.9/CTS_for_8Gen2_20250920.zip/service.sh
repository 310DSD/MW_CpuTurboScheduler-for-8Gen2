#!/system/bin/sh

MODDIR=${0%/*}

wait_until_login() {

    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 0.1
    done

    local test_file="/sdcard/Android/.PERMISSION_TEST_FREEZEIT"
    true >"$test_file"
    while [ ! -f "$test_file" ]; do
        sleep 2
        true >"$test_file"
    done
    rm "$test_file"
}

configure_xiaomi_module() {
    killall -9 mi_thermald
    for svc in mimd-service mimd-service2_0 miuibooster; do
        stop $svc
    done
    
    mask_val "0" "/sys/module/mist/parameters/dflt_bw_enable"
    mask_val "0" "/sys/module/mist/parameters/dflt_lat_enable"
    mask_val "0" "/sys/module/mist/parameters/dflt_ddr_boost"
    mask_val "0" "/sys/module/mist/parameters/gflt_enable"
    mask_val "0" "/sys/module/mist/parameters/mist_memlat_vote_enable"
    mask_val "0" "/sys/module/migt/parameters/glk_freq_limit_walt"
    mask_val "0" "/sys/module/metis/parameters/cluaff_control"
    mask_val "0" "/sys/module/metis/parameters/preempt_sysprocess"
    mask_val "0" "/sys/module/metis/parameters/mi_fboost_enable"
    mask_val "0" "/sys/module/metis/parameters/mi_freq_enable"
    mask_val "0" "/sys/module/metis/parameters/suspend_vip_enable"
    mask_val "0" "/sys/module/metis/parameters/bug_detect"
    mask_val "0" "/sys/module/metis/parameters/mi_boost_duration"
    mask_val "0" /proc/sys/migt/enable_pkg_monitor
    mask_val "0" /sys/module/migt/parameters/enable_pkg_monitor
}

wait_until_login
configure_xiaomi_module
chmod 777 $MODDIR/vtools/*
/data/powercfg.sh $(cat "/sdcard/Android/MW_CpuSpeedController/config.txt")
chmod 777  $MODDIR/*
$MODDIR/MW_CpuSpeedController
echo "fast" > /dev/fas_rs/mode
